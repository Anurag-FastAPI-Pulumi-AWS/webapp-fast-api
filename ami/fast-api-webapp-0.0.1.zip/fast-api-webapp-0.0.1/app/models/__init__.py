from .User import User

all_models = [User]